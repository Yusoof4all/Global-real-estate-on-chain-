import { useState, useRef, useCallback } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { Loader2, ShieldCheck, Upload, FileText, Image, X, CheckCircle2, AlertCircle, ChevronRight } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import { REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl } from '@/hooks/useRealEstateContract'

type DocType = 'passport' | 'national_id' | 'drivers_license' | 'residence_permit'

const DOC_TYPES: { value: DocType; label: string; description: string }[] = [
  { value: 'passport', label: 'Passport', description: 'International travel document' },
  { value: 'national_id', label: 'National ID', description: 'Government-issued identity card' },
  { value: 'drivers_license', label: "Driver's License", description: 'State or national driving permit' },
  { value: 'residence_permit', label: 'Residence Permit', description: 'Official residency document' },
]

type FlowStep = 'select_doc' | 'upload' | 'processing' | 'sign' | 'done' | 'error'

interface KycAuthorization {
  user: string
  level: number
  nonce: string
  expiry: string
  sig: `0x${string}`
}

function DropZone({
  file,
  onFile,
  onClear,
}: {
  file: File | null
  onFile: (f: File) => void
  onClear: () => void
}) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragging(false)
      const f = e.dataTransfer.files[0]
      if (f) onFile(f)
    },
    [onFile],
  )

  const isImage = file?.type.startsWith('image/')

  if (file) {
    return (
      <div
        className="relative rounded-2xl border-2 overflow-hidden"
        style={{ borderColor: 'var(--success)', background: 'rgba(26,128,71,0.04)' }}
      >
        {isImage ? (
          <img
            src={URL.createObjectURL(file)}
            alt="Document preview"
            className="w-full max-h-48 object-contain"
          />
        ) : (
          <div className="flex items-center gap-3 p-4">
            <div
              className="flex size-10 items-center justify-center rounded-xl"
              style={{ background: 'rgba(26,128,71,0.1)' }}
            >
              <FileText className="size-5" style={{ color: 'var(--success)' }} />
            </div>
            <div>
              <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                {file.name}
              </div>
              <div className="text-xs" style={{ color: 'var(--muted)' }}>
                {(file.size / 1024).toFixed(0)} KB · PDF
              </div>
            </div>
          </div>
        )}
        <button
          onClick={onClear}
          className="absolute top-2 right-2 flex size-6 items-center justify-center rounded-full transition-colors hover:bg-black/10"
          style={{ background: 'rgba(255,255,255,0.8)' }}
          aria-label="Remove file"
        >
          <X className="size-3.5" style={{ color: 'var(--ink-2)' }} />
        </button>
        <div
          className="px-3 py-1.5 text-xs font-medium"
          style={{ color: 'var(--success)', background: 'rgba(26,128,71,0.06)' }}
        >
          <CheckCircle2 className="inline size-3 mr-1" />
          Document ready
        </div>
      </div>
    )
  }

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className="cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all"
      style={{
        borderColor: dragging ? 'var(--accent)' : 'var(--border)',
        background: dragging ? 'rgba(18,45,69,0.03)' : 'var(--surface-muted)',
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,application/pdf"
        className="sr-only"
        onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }}
      />
      <div className="flex flex-col items-center gap-3">
        <div
          className="flex size-12 items-center justify-center rounded-2xl"
          style={{ background: 'rgba(18,45,69,0.06)' }}
        >
          <Upload className="size-5" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>
            Drop your document here
          </div>
          <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
            or click to browse · JPEG, PNG, WebP, PDF · max 20 MB
          </div>
        </div>
        <div className="flex gap-2">
          {(['image/jpeg', 'image/png', 'application/pdf'] as const).map(t => (
            <span
              key={t}
              className="flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs font-medium"
              style={{ background: 'var(--border)', color: 'var(--muted)' }}
            >
              {t.startsWith('image') ? <Image className="size-2.5" /> : <FileText className="size-2.5" />}
              {t.split('/')[1].toUpperCase()}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function KycFlow({ onComplete }: { onComplete?: () => void }) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })

  const [step, setStep] = useState<FlowStep>('select_doc')
  const [docType, setDocType] = useState<DocType | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [errorMsg, setErrorMsg] = useState('')
  const [auth, setAuth] = useState<KycAuthorization | null>(null)

  const wrongChain = chainId !== CHAIN_ID

  const handleSubmitDoc = async () => {
    if (!file || !docType || !address) return
    setStep('processing')
    setErrorMsg('')

    const formData = new FormData()
    formData.append('wallet', address)
    formData.append('docType', docType)
    formData.append('document', file)

    try {
      const res = await fetch('/api/kyc/submit', { method: 'POST', body: formData })
      const data = await res.json() as { ok?: boolean; error?: string; authorization?: KycAuthorization }

      if (!res.ok || !data.ok || !data.authorization) {
        setErrorMsg(data.error ?? 'Verification failed. Please try again.')
        setStep('error')
        return
      }

      setAuth(data.authorization)
      setStep('sign')
    } catch {
      setErrorMsg('Network error — is the KYC server running?')
      setStep('error')
    }
  }

  const handleSubmitOnChain = () => {
    if (!auth) return
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }

    writeContract({
      address: REAL_ESTATE_ADDRESS,
      abi: REAL_ESTATE_ABI,
      functionName: 'verifyWithSignature',
      args: [
        auth.user as `0x${string}`,
        auth.level,
        BigInt(auth.nonce),
        BigInt(auth.expiry),
        auth.sig,
      ],
      chainId: CHAIN_ID,
    })
  }

  // When tx confirms, move to done
  if (isSuccess && step === 'sign') {
    setStep('done')
    toast.success('KYC verified on-chain!')
    onComplete?.()
  }

  const busy = isPending || isConfirming

  return (
    <div className="rounded-2xl overflow-hidden border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
      {/* Header */}
      <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
            <ShieldCheck className="size-4" style={{ color: 'var(--accent)' }} />
          </div>
          <div>
            <div className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Identity Verification</div>
            <div className="text-xs" style={{ color: 'var(--muted)' }}>Upload a government document to get KYC-verified instantly</div>
          </div>
        </div>

        {/* Step pills */}
        <div className="flex items-center gap-1.5 mt-3">
          {(['select_doc', 'upload', 'processing', 'sign', 'done'] as const).map((s, i) => {
            const steps: FlowStep[] = ['select_doc', 'upload', 'processing', 'sign', 'done']
            const current = steps.indexOf(step === 'error' ? 'processing' : step)
            const past = i < current
            const active = i === current
            return (
              <div key={s} className="flex items-center gap-1.5">
                <div
                  className="size-2 rounded-full transition-all"
                  style={{
                    background: active ? 'var(--accent)' : past ? 'var(--success)' : 'var(--border)',
                  }}
                />
                {i < 4 && <div className="h-px w-4" style={{ background: 'var(--border)' }} />}
              </div>
            )
          })}
          <span className="ml-2 text-xs" style={{ color: 'var(--muted)' }}>
            {step === 'select_doc' && 'Choose document type'}
            {step === 'upload' && 'Upload document'}
            {step === 'processing' && 'Verifying…'}
            {step === 'sign' && 'Confirm on-chain'}
            {step === 'done' && 'Verified!'}
            {step === 'error' && 'Verification failed'}
          </span>
        </div>
      </div>

      <div className="p-5">
        <AnimatePresence mode="wait">

          {/* Step 1 — Select document type */}
          {step === 'select_doc' && (
            <motion.div key="select" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-2">
              <p className="text-sm" style={{ color: 'var(--ink-2)' }}>What type of document will you upload?</p>
              <div className="grid grid-cols-2 gap-2">
                {DOC_TYPES.map(dt => (
                  <button
                    key={dt.value}
                    onClick={() => setDocType(dt.value)}
                    className="text-left rounded-xl p-3 border-2 transition-all"
                    style={{
                      borderColor: docType === dt.value ? 'var(--accent)' : 'var(--border)',
                      background: docType === dt.value ? 'rgba(18,45,69,0.04)' : 'var(--surface-muted)',
                    }}
                  >
                    <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{dt.label}</div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{dt.description}</div>
                  </button>
                ))}
              </div>
              <button
                disabled={!docType}
                onClick={() => setStep('upload')}
                className="mt-3 w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: 'var(--accent)' }}
              >
                Continue <ChevronRight className="size-4" />
              </button>
            </motion.div>
          )}

          {/* Step 2 — Upload */}
          {step === 'upload' && (
            <motion.div key="upload" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-4">
              <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                Upload a clear photo or scan of your <strong>{DOC_TYPES.find(d => d.value === docType)?.label}</strong>.
              </p>
              <DropZone file={file} onFile={setFile} onClear={() => setFile(null)} />
              <div className="rounded-xl px-3 py-2.5 text-xs" style={{ background: 'rgba(18,45,69,0.04)', color: 'var(--muted)' }}>
                Your document is processed server-side for format validation only. No data is stored. Your wallet address is linked to the on-chain KYC record.
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setStep('select_doc')}
                  className="rounded-2xl px-4 py-3 text-sm font-medium transition-all hover:bg-black/5"
                  style={{ color: 'var(--ink-2)' }}
                >
                  Back
                </button>
                <button
                  disabled={!file}
                  onClick={() => { void handleSubmitDoc() }}
                  className="flex-1 flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: 'var(--accent)' }}
                >
                  <ShieldCheck className="size-4" /> Verify Document
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 3 — Processing */}
          {step === 'processing' && (
            <motion.div key="processing" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="py-8 flex flex-col items-center gap-4 text-center">
              <div className="relative">
                <div className="flex size-14 items-center justify-center rounded-2xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                  <ShieldCheck className="size-7" style={{ color: 'var(--accent)' }} />
                </div>
                <div className="absolute -top-1 -right-1 flex size-5 items-center justify-center rounded-full" style={{ background: 'var(--accent)' }}>
                  <Loader2 className="size-3 text-white animate-spin" />
                </div>
              </div>
              <div>
                <div className="font-semibold" style={{ color: 'var(--ink)' }}>Verifying your document</div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Checking format and generating authorization…</div>
              </div>
            </motion.div>
          )}

          {/* Step 4 — Sign on-chain */}
          {step === 'sign' && auth && (
            <motion.div key="sign" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="space-y-4">
              <div className="flex items-center gap-3 rounded-xl p-3.5" style={{ background: 'rgba(26,128,71,0.06)', border: '1px solid rgba(26,128,71,0.15)' }}>
                <CheckCircle2 className="size-5 shrink-0" style={{ color: 'var(--success)' }} />
                <div>
                  <div className="text-sm font-semibold" style={{ color: 'var(--success)' }}>Document verified</div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>Your authorization is signed and ready. Submit it to the blockchain to complete KYC.</div>
                </div>
              </div>

              <div className="rounded-xl p-3.5 space-y-1.5 text-xs" style={{ background: 'var(--surface-muted)' }}>
                <div className="flex justify-between">
                  <span style={{ color: 'var(--muted)' }}>KYC Level</span>
                  <span className="font-semibold" style={{ color: 'var(--ink)' }}>Full (Level 2)</span>
                </div>
                <div className="flex justify-between">
                  <span style={{ color: 'var(--muted)' }}>Expires</span>
                  <span className="font-medium mono tabular-nums" style={{ color: 'var(--ink-2)' }}>
                    {new Date(Number(auth.expiry) * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span style={{ color: 'var(--muted)' }}>Nonce</span>
                  <span className="font-medium mono" style={{ color: 'var(--ink-2)' }}>{auth.nonce}</span>
                </div>
              </div>

              {isSuccess && hash ? (
                <div className="rounded-2xl p-4 text-center" style={{ background: 'rgba(26,128,71,0.06)' }}>
                  <p className="font-semibold text-sm" style={{ color: 'var(--success)' }}>KYC complete!</p>
                  <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-xs underline mt-1 block" style={{ color: 'var(--accent-hover)' }}>View on explorer</a>
                </div>
              ) : (
                <button
                  disabled={busy}
                  onClick={handleSubmitOnChain}
                  className="w-full flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                  style={{ background: 'var(--accent)' }}
                >
                  {wrongChain ? 'Switch to Arc Testnet'
                    : busy ? <><Loader2 className="size-4 animate-spin" />{isPending ? 'Confirm in wallet…' : 'Confirming…'}</>
                    : <><ShieldCheck className="size-4" /> Submit KYC On-Chain</>}
                </button>
              )}
            </motion.div>
          )}

          {/* Done */}
          {step === 'done' && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="py-6 flex flex-col items-center gap-3 text-center">
              <div className="flex size-14 items-center justify-center rounded-2xl" style={{ background: 'rgba(26,128,71,0.1)' }}>
                <CheckCircle2 className="size-8" style={{ color: 'var(--success)' }} />
              </div>
              <div>
                <div className="font-bold text-base" style={{ color: 'var(--ink)' }}>Identity Verified</div>
                <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>You can now create listings and initiate transactions.</div>
              </div>
              {hash && (
                <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-xs underline" style={{ color: 'var(--accent-hover)' }}>View on explorer</a>
              )}
            </motion.div>
          )}

          {/* Error */}
          {step === 'error' && (
            <motion.div key="error" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <div className="flex items-start gap-3 rounded-xl p-3.5" style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)' }}>
                <AlertCircle className="size-5 shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <div>
                  <div className="text-sm font-semibold" style={{ color: 'var(--danger)' }}>Verification failed</div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{errorMsg}</div>
                </div>
              </div>
              <button
                onClick={() => { setStep('upload'); setFile(null); setErrorMsg('') }}
                className="w-full rounded-2xl py-3 text-sm font-semibold text-white"
                style={{ background: 'var(--accent)' }}
              >
                Try Again
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}
