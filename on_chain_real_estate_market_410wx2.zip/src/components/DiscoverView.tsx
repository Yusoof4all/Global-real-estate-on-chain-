import { useState } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { MapPin, DollarSign, Key, ArrowRight, Search, Building, Home, Warehouse, Loader2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  useListingCount, useListing, useUserProfile, formatUsdc,
  REAL_ESTATE_ABI, REAL_ESTATE_ADDRESS, CHAIN_ID, getTxUrl, ListingData
} from '@/hooks/useRealEstateContract'
import KycBadge from './KycBadge'
import ReputationBar from './ReputationBar'

const propertyIcons: Record<string, React.ReactNode> = {
  apartment: <Building className="size-4" />,
  house: <Home className="size-4" />,
  commercial: <Warehouse className="size-4" />,
}

function ListingCard({ id, onAction }: { id: bigint; onAction: (listing: ListingData, mode: 'buy' | 'rent') => void }) {
  const { data: listing } = useListing(id)
  const { data: ownerProfile } = useUserProfile(listing?.owner)
  const [hovered, setHovered] = useState(false)

  if (!listing || !listing.active) return null

  const ownerReputation = ownerProfile?.reputationScore ?? 250
  const ownerKyc = ownerProfile?.kycLevel ?? 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      className="rounded-2xl overflow-hidden cursor-pointer transition-shadow"
      style={{
        background: 'var(--surface-strong)',
        border: `1px solid ${hovered ? 'var(--border-strong)' : 'var(--border)'}`,
        boxShadow: hovered ? '0 4px 24px rgba(18,45,69,0.10)' : '0 1px 4px rgba(18,45,69,0.05)',
      }}
    >
      {/* Property type strip */}
      <div className="h-1" style={{ background: listing.forSale && listing.forRent ? 'linear-gradient(90deg, #122d45 50%, #1a8047 50%)' : listing.forSale ? 'var(--accent)' : 'var(--success)' }} />

      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="display font-semibold truncate text-sm" style={{ color: 'var(--ink)' }}>{listing.title}</h3>
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="size-3 shrink-0" style={{ color: 'var(--muted)' }} />
              <span className="text-xs truncate" style={{ color: 'var(--muted)' }}>{listing.location}</span>
            </div>
          </div>
          <div className="flex items-center justify-center size-8 rounded-xl shrink-0" style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}>
            {propertyIcons[listing.propertyType?.toLowerCase()] ?? <Building className="size-4" />}
          </div>
        </div>

        {/* Prices */}
        <div className="flex flex-wrap gap-2 mb-3">
          {listing.forSale && (
            <div className="flex items-center gap-1.5 rounded-xl px-2.5 py-1.5" style={{ background: 'rgba(18,45,69,0.06)' }}>
              <DollarSign className="size-3" style={{ color: 'var(--accent)' }} />
              <span className="text-xs font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>{formatUsdc(listing.priceUsdc)} USDC</span>
              <span className="text-xs" style={{ color: 'var(--muted)' }}>buy</span>
            </div>
          )}
          {listing.forRent && (
            <div className="flex items-center gap-1.5 rounded-xl px-2.5 py-1.5" style={{ background: 'rgba(26,128,71,0.06)' }}>
              <Key className="size-3" style={{ color: 'var(--success)' }} />
              <span className="text-xs font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>{formatUsdc(listing.rentPerMonthUsdc)} USDC</span>
              <span className="text-xs" style={{ color: 'var(--muted)' }}>/mo</span>
            </div>
          )}
        </div>

        {/* Owner reputation */}
        <div className="mb-3 p-2.5 rounded-xl" style={{ background: 'var(--surface-muted)' }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Owner</span>
            <KycBadge level={ownerKyc} size="sm" />
          </div>
          <ReputationBar score={ownerReputation} showLabel={false} />
          <div className="mt-1 text-xs tabular-nums font-medium" style={{ color: 'var(--ink-2)' }}>{ownerReputation}/500</div>
        </div>

        {/* CTAs */}
        <div className="flex gap-2">
          {listing.forSale && (
            <button
              onClick={() => onAction(listing, 'buy')}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold text-white transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ background: 'var(--accent)' }}
            >
              Buy <ArrowRight className="size-3" />
            </button>
          )}
          {listing.forRent && (
            <button
              onClick={() => onAction(listing, 'rent')}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ background: 'rgba(26,128,71,0.10)', color: 'var(--success)' }}
            >
              Rent <Key className="size-3" />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  )
}

function ListingCountLoader({ count, filter, onAction }: { count: number; filter: string; onAction: (listing: ListingData, mode: 'buy' | 'rent') => void }) {
  const ids = Array.from({ length: count }, (_, i) => BigInt(count - i))
  const filtered = filter === 'all' ? ids : filter === 'buy' ? ids : ids
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {filtered.map(id => <ListingCard key={id.toString()} id={id} onAction={onAction} />)}
    </div>
  )
}

interface ActionSheetProps {
  listing: ListingData
  mode: 'buy' | 'rent'
  onClose: () => void
}

function ActionSheet({ listing, mode, onClose }: ActionSheetProps) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const { writeContract, data: hash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash })
  const wrongChain = chainId !== CHAIN_ID

  const handleAction = () => {
    if (wrongChain) { switchChain({ chainId: CHAIN_ID }); return }
    if (!address) return
    if (mode === 'buy') {
      writeContract({
        address: REAL_ESTATE_ADDRESS,
        abi: REAL_ESTATE_ABI,
        functionName: 'initiatePurchase',
        args: [listing.listingId],
        chainId: CHAIN_ID,
      })
    } else {
      writeContract({
        address: REAL_ESTATE_ADDRESS,
        abi: REAL_ESTATE_ABI,
        functionName: 'initiateRent',
        args: [listing.listingId],
        chainId: CHAIN_ID,
      })
    }
  }

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center gap-4 py-4 text-center">
        <div className="flex size-12 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.1)' }}>
          <span style={{ color: 'var(--success)', fontSize: 24 }}>✓</span>
        </div>
        <div>
          <div className="font-semibold" style={{ color: 'var(--ink)' }}>
            {mode === 'buy' ? 'Purchase Initiated' : 'Rent Initiated'}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
            Go to My Deals to fund the escrow and continue.
          </div>
        </div>
        {hash && (
          <a href={getTxUrl(hash)} target="_blank" rel="noopener noreferrer" className="text-xs underline" style={{ color: 'var(--accent-hover)' }}>View on explorer</a>
        )}
        <button onClick={onClose} className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>Done</button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h3 className="display font-bold" style={{ color: 'var(--ink)' }}>
          {mode === 'buy' ? 'Initiate Purchase' : 'Initiate Rental'}
        </h3>
        <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>{listing.title} · {listing.location}</p>
      </div>

      <div className="rounded-2xl p-4 space-y-2" style={{ background: 'var(--surface-muted)' }}>
        {mode === 'buy' ? (
          <>
            <Row label="Purchase Price" value={`${formatUsdc(listing.priceUsdc)} USDC`} />
            <Row label="Platform Fee (1.5%)" value={`${formatUsdc(listing.priceUsdc * 150n / 10000n)} USDC`} />
            <Row label="Total Required" value={`${formatUsdc(listing.priceUsdc + listing.priceUsdc * 150n / 10000n)} USDC`} bold />
            <div className="pt-2 text-xs" style={{ color: 'var(--muted)' }}>Funds go into escrow. You confirm inspection before releasing to seller.</div>
          </>
        ) : (
          <>
            <Row label="Monthly Rent" value={`${formatUsdc(listing.rentPerMonthUsdc)} USDC`} />
            <Row label="Deposit (2 months)" value={`${formatUsdc(listing.rentPerMonthUsdc * 2n)} USDC`} />
            <div className="pt-2 text-xs" style={{ color: 'var(--muted)' }}>Deposit is held in escrow. Returned on clean termination.</div>
          </>
        )}
      </div>

      <button
        disabled={!address || isPending || isConfirming}
        onClick={handleAction}
        className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed"
        style={{ background: mode === 'buy' ? 'var(--accent)' : 'var(--success)' }}
      >
        {!address ? 'Connect Wallet'
          : wrongChain ? 'Switch to Arc Testnet'
          : isPending ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirm in wallet...</span>
          : isConfirming ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Confirming...</span>
          : mode === 'buy' ? 'Initiate Purchase' : 'Initiate Rental'}
      </button>
    </div>
  )
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      <span className={`text-xs tabular-nums ${bold ? 'font-bold' : 'font-medium'}`} style={{ color: bold ? 'var(--ink)' : 'var(--ink-2)' }}>{value}</span>
    </div>
  )
}

export default function DiscoverView() {
  const { data: countRaw } = useListingCount()
  const count = Number(countRaw ?? 0n)
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [actionListing, setActionListing] = useState<{ listing: ListingData; mode: 'buy' | 'rent' } | null>(null)

  const filters = [
    { id: 'all', label: 'All' },
    { id: 'buy', label: 'For Sale' },
    { id: 'rent', label: 'For Rent' },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Hero */}
      <div className="mb-8">
        <h1 className="display text-3xl font-bold tracking-tight mb-1" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
          Global Real Estate,<br />On-Chain
        </h1>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>KYC-verified listings. USDC escrow. Transparent reputation.</p>
      </div>

      {/* Search + filter row */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 flex items-center gap-2 rounded-xl px-3 py-2.5 border" style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
          <Search className="size-4 shrink-0" style={{ color: 'var(--muted)' }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search city, country, property type…"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400"
            style={{ color: 'var(--ink)' }}
          />
        </div>
        <div className="flex items-center gap-1 rounded-xl p-1" style={{ background: 'var(--surface-muted)' }}>
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className="rounded-lg px-3 py-1.5 text-xs font-medium transition-all"
              style={{
                background: filter === f.id ? 'white' : 'transparent',
                color: filter === f.id ? 'var(--ink)' : 'var(--muted)',
                boxShadow: filter === f.id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-2 mb-6">
        <div className="px-3 py-1 rounded-full text-xs font-medium" style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
          {count} {count === 1 ? 'listing' : 'listings'} on-chain
        </div>
      </div>

      {!REAL_ESTATE_ADDRESS ? (
        <div className="rounded-2xl p-8 text-center" style={{ background: 'var(--surface-muted)', border: '1px dashed var(--border)' }}>
          <Building className="size-8 mx-auto mb-3" style={{ color: 'var(--muted)' }} />
          <p className="font-medium" style={{ color: 'var(--ink)' }}>Contract not deployed yet</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Deploy the RealEstate contract and set VITE_CONTRACT_ADDRESS to start seeing live listings.</p>
        </div>
      ) : count === 0 ? (
        <div className="rounded-2xl p-8 text-center" style={{ background: 'var(--surface-muted)', border: '1px dashed var(--border)' }}>
          <Building className="size-8 mx-auto mb-3" style={{ color: 'var(--muted)' }} />
          <p className="font-medium" style={{ color: 'var(--ink)' }}>No listings yet</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Be the first to list a property.</p>
        </div>
      ) : (
        <ListingCountLoader count={count} filter={filter} onAction={(listing, mode) => setActionListing({ listing, mode })} />
      )}

      {/* Action sheet */}
      <AnimatePresence>
        {actionListing && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end justify-center"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setActionListing(null)}
          >
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />
            <motion.div
              className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
              style={{ background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(40px)' }}
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="h-1" style={{ background: actionListing.mode === 'buy' ? 'var(--accent)' : 'var(--success)' }} />
              <div className="flex justify-center pt-3 pb-1">
                <div className="h-1 w-10 rounded-full bg-black/10" />
              </div>
              <div className="px-5 pb-8 pt-2">
                <ActionSheet listing={actionListing.listing} mode={actionListing.mode} onClose={() => setActionListing(null)} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
