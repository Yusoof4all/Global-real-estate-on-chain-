import { useState } from 'react'
import Header from '@/components/Header'
import DiscoverView from '@/components/DiscoverView'
import ListPropertyView from '@/components/ListPropertyView'
import TransactionsView from '@/components/TransactionsView'
import ProfileView from '@/components/ProfileView'

type Tab = 'discover' | 'list' | 'transactions' | 'profile'

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('discover')

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      <Header activeTab={activeTab} onTabChange={tab => setActiveTab(tab as Tab)} />
      <main>
        {activeTab === 'discover' && <DiscoverView />}
        {activeTab === 'list' && <ListPropertyView />}
        {activeTab === 'transactions' && <TransactionsView />}
        {activeTab === 'profile' && <ProfileView />}
      </main>
    </div>
  )
}
