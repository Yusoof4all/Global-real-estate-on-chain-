# PropChain — On-Chain Real Estate

> Built with Arc Studio - money-powered apps in minutes

## Deployed Contracts

### RealEstate.sol — Arc Testnet (v2 — EIP-712 self-KYC)
- Address: `0x424194693a2fca7b7b7ac62439491e9ce6d24e65`
- Chain: Arc Testnet (chainId 5042002)
- USDC Token: `0x3600000000000000000000000000000000000000`
- KYC Verifier: `0x5B12Ce46C7194aD57d143bC22847224047b1Ef42` (platform deployer)
- KYC Signer: `0x17e71619c55213Fd6644b4509e0b5bcc6CEB840A` (backend hot-wallet)
- Explorer: https://explorer.testnet.arc.io/address/0x424194693a2fca7b7b7ac62439491e9ce6d24e65
- Deployed: 2026-10-11

### RealEstate.sol — Arc Testnet (v1 — superseded)
- Address: `0x358dbeeb4f479f61225d699c12ec9294040f6e1a`
- Deployed: 2026-10-06

This is the **project memory** - what Arc Studio remembers about building this app. It helps future agents (or humans) understand and extend the project.

---

## What This App Does

[Brief description of what the app does and its primary use case]

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS
- Web3: wagmi v2, viem v2, ConnectKit
- Contracts: Solidity 0.8.28 + Foundry. Sources in `contracts/`, unit tests in `contracts/test/*.t.sol`. Build with `bun run contracts:build` (`forge build`), test with `bun run contracts:test` (`forge test`).
- Wallet: injected (MetaMask, etc.)
- Chain: Arc Testnet (Chain ID: 5042002, imported from `viem/chains`)
- Token: USDC (6 decimals) (Address: 0x3600000000000000000000000000000000000000, Chain: Arc Testnet)
- Toasts: Sonner

## Key Files

- `src/App.tsx` - Main application logic
- `src/components/` - UI components
- `src/config.ts` - wagmi config (chains, connectors, transports)

## To Run

```bash
bun install
bun run dev
```
