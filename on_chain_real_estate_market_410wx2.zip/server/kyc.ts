/**
 * PropChain KYC Backend
 * Accepts a government document upload, validates it, then signs an EIP-712
 * KycAuthorization that the user submits on-chain via verifyWithSignature().
 *
 * Runs on port 3001. Vite proxies /api → http://localhost:3001.
 */

import { createServer, IncomingMessage, ServerResponse } from 'http'
import { privateKeyToAccount } from 'viem/accounts'
import { hashTypedData } from 'viem'
import { randomBytes } from 'crypto'

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const PORT = 3001

// KYC_SIGNER_PRIVATE_KEY must be a 0x-prefixed 32-byte hex private key.
let rawKey = process.env.KYC_SIGNER_PRIVATE_KEY
if (!rawKey || rawKey.length < 66) {
  const generated = '0x' + randomBytes(32).toString('hex')
  console.error(
    '\n[KYC] KYC_SIGNER_PRIVATE_KEY not set — generated a one-time key for this session:',
    generated,
    '\nSet KYC_SIGNER_PRIVATE_KEY=' + generated + ' in your .env and restart the backend.\n',
  )
  rawKey = generated
}

const signerAccount = privateKeyToAccount(rawKey as `0x${string}`)

console.log('[KYC] Signer address:', signerAccount.address)
console.log('[KYC] Call setKycSigner("' + signerAccount.address + '") on the deployed contract.')

const CONTRACT_ADDRESS = (process.env.VITE_CONTRACT_ADDRESS ?? '') as `0x${string}`
const CHAIN_ID = 5042002 // Arc Testnet

// ---------------------------------------------------------------------------
// EIP-712 helpers
// ---------------------------------------------------------------------------

const domain = {
  name: 'PropChain',
  version: '1',
  chainId: CHAIN_ID,
  verifyingContract: CONTRACT_ADDRESS,
} as const

const types = {
  KycAuthorization: [
    { name: 'user', type: 'address' },
    { name: 'level', type: 'uint8' },
    { name: 'nonce', type: 'uint256' },
    { name: 'expiry', type: 'uint256' },
  ],
} as const

async function signKycAuthorization(
  user: `0x${string}`,
  level: number,
  nonce: bigint,
  expiry: bigint,
): Promise<`0x${string}`> {
  const message = { user, level, nonce, expiry }
  const hash = hashTypedData({ domain, types, primaryType: 'KycAuthorization', message })
  return signerAccount.sign({ hash })
}

// ---------------------------------------------------------------------------
// Multipart parser (zero external deps)
// ---------------------------------------------------------------------------

function parseBoundary(contentType: string): string | null {
  const m = contentType.match(/boundary=([^\s;]+)/)
  return m ? m[1] : null
}

interface MultipartPart {
  fieldName: string
  filename?: string
  mimeType: string
  data: Buffer
}

function parseMultipart(body: Buffer, boundary: string): MultipartPart[] {
  const sep = Buffer.from('--' + boundary)
  const parts: MultipartPart[] = []

  let offset = 0
  while (offset < body.length) {
    const start = body.indexOf(sep, offset)
    if (start === -1) break
    const headerStart = start + sep.length + 2 // skip \r\n
    const headerEnd = body.indexOf(Buffer.from('\r\n\r\n'), headerStart)
    if (headerEnd === -1) break

    const headerStr = body.slice(headerStart, headerEnd).toString()
    const dataStart = headerEnd + 4
    const nextBoundary = body.indexOf(sep, dataStart)
    const dataEnd = nextBoundary === -1 ? body.length : nextBoundary - 2

    const cdMatch = headerStr.match(/Content-Disposition:[^\r\n]*name="([^"]+)"/)
    const fnMatch = headerStr.match(/filename="([^"]+)"/)
    const ctMatch = headerStr.match(/Content-Type:\s*([^\r\n]+)/)

    if (cdMatch) {
      parts.push({
        fieldName: cdMatch[1],
        filename: fnMatch?.[1],
        mimeType: ctMatch?.[1].trim() ?? 'application/octet-stream',
        data: body.slice(dataStart, dataEnd),
      })
    }

    offset = nextBoundary === -1 ? body.length : nextBoundary
  }

  return parts
}

// ---------------------------------------------------------------------------
// Document validation
// ---------------------------------------------------------------------------

const ACCEPTED_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'application/pdf',
])

function detectFileType(data: Buffer): string | null {
  if (data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff) return 'image/jpeg'
  if (data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47) return 'image/png'
  if (data[0] === 0x52 && data[1] === 0x49 && data[2] === 0x46 && data[3] === 0x46) return 'image/webp'
  if (data[0] === 0x25 && data[1] === 0x50 && data[2] === 0x44 && data[3] === 0x46) return 'application/pdf'
  return null
}

function validateDocument(data: Buffer, declaredMime: string): { ok: boolean; reason?: string } {
  if (data.length < 100) return { ok: false, reason: 'File too small to be a valid document.' }
  if (data.length > 20 * 1024 * 1024) return { ok: false, reason: 'File exceeds 20 MB limit.' }

  const detected = detectFileType(data)
  if (!detected) return { ok: false, reason: 'Unrecognised file format. Upload a JPEG, PNG, WebP, or PDF.' }
  if (!ACCEPTED_TYPES.has(detected)) return { ok: false, reason: `File type ${detected} is not accepted.` }

  const declared = declaredMime.split(';')[0].trim().toLowerCase()
  if (declared && declared !== 'application/octet-stream' && declared !== detected) {
    const ok =
      (declared === 'image/jpg' && detected === 'image/jpeg') ||
      (declared === 'image/jpeg' && detected === 'image/jpeg')
    if (!ok) return { ok: false, reason: 'Declared MIME type does not match file content.' }
  }

  return { ok: true }
}

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
  })
  res.end(payload)
}

async function readBody(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  return Buffer.concat(chunks)
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------

const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  // CORS pre-flight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    res.end()
    return
  }

  // Health check
  if (req.method === 'GET' && req.url === '/health') {
    sendJson(res, 200, { ok: true, signer: signerAccount.address })
    return
  }

  // POST /kyc/submit
  if (req.method === 'POST' && req.url === '/kyc/submit') {
    const contentType = req.headers['content-type'] ?? ''
    const boundary = parseBoundary(contentType)
    if (!boundary) {
      sendJson(res, 400, { error: 'Expected multipart/form-data' })
      return
    }

    const body = await readBody(req)
    const parts = parseMultipart(body, boundary)

    const walletField = parts.find(p => p.fieldName === 'wallet')
    const docTypeField = parts.find(p => p.fieldName === 'docType')
    const docFile = parts.find(p => p.fieldName === 'document')

    if (!walletField || !docTypeField || !docFile) {
      sendJson(res, 400, { error: 'Missing required fields: wallet, docType, document' })
      return
    }

    const wallet = walletField.data.toString().trim().toLowerCase()
    if (!/^0x[0-9a-f]{40}$/.test(wallet)) {
      sendJson(res, 400, { error: 'Invalid wallet address' })
      return
    }

    const validation = validateDocument(docFile.data, docFile.mimeType)
    if (!validation.ok) {
      sendJson(res, 422, { error: validation.reason })
      return
    }

    // Sign a KYC authorization for level 2 (Full KYC), expiry 30 minutes
    const expiry = BigInt(Math.floor(Date.now() / 1000) + 30 * 60)
    const nonce = 0n
    const level = 2

    let sig: `0x${string}`
    try {
      sig = await signKycAuthorization(wallet as `0x${string}`, level, nonce, expiry)
    } catch (err) {
      console.error('[KYC] Signing error:', err)
      sendJson(res, 500, { error: 'Failed to sign authorization' })
      return
    }

    console.log(`[KYC] Authorized ${wallet} level=${level} expiry=${expiry}`)

    sendJson(res, 200, {
      ok: true,
      authorization: {
        user: wallet,
        level,
        nonce: nonce.toString(),
        expiry: expiry.toString(),
        sig,
        signerAddress: signerAccount.address,
      },
    })
    return
  }

  sendJson(res, 404, { error: 'Not found' })
})

server.listen(PORT, () => {
  console.log(`[KYC] Backend listening on http://localhost:${PORT}`)
})
